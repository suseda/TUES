public class Rook extends Figure
{
    public Rook(Figure[][] game, String position, String player, String sign)
    {
        super(game,position, player,sign);
    }
}
