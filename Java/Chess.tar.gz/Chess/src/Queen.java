public class Queen extends Figure
{
    public Queen(Figure[][] game, String position, String player, String sign)
    {
        super(game,position, player,sign);
    }
}
