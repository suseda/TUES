public class Knight extends Figure
{

    public Knight(Figure[][] game, String position, String player, String sign)
    {
        super(game,position, player,sign);
    }
}
