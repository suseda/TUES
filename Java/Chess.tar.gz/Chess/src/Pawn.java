public class Pawn extends Figure
{

    public Pawn(Figure[][] game, String position, String player, String sign)
    {
        super(game,position, player,sign);
    }



}
