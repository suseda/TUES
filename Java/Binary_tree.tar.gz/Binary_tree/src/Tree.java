public class Tree
{
    Node root;

    public Tree(Node root)
    {
        this.root = root;
    }

    public void add_in_tree(Node n)
    {
        while(root != null)
        {
            if (root.data > n.data && root.left == null)
            {
                root.left = n;
                break;
            }

            if (root.data > n.data)
                root = root.left;

            if (root.data < n.data && root.right == null)
            {
                root.right = n;
                break;
            }

            if (root.data < n.data)
                root = root.right;
            System.out.println("Here");
        }
    }

    public void add(int data)
    {
        Node new_node = new Node(data);
        add_in_tree(new_node);
    }

    public void print_tree(Node root)
    {
        if(root == null)
            return;
        System.out.print(root.data);
        System.out.print(" ");
        print_tree(root.left);
        print_tree(root.right);
    }
}
