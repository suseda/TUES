public class Node
{
    int data;
    Node right,left;


    public Node(int data)
    {
        this.data = data;
        this.left = null;
        this.right = null;
    }

}
