public class Main
{
    public static void main(String[] args)
    {
        Node root = new Node(8);
        Tree t = new Tree(root);
        t.add(4);
        t.add(10);
        t.add(12);
        t.add(9);
        t.print_tree(root);
    }
}