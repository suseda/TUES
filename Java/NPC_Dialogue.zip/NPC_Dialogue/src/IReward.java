@FunctionalInterface
public interface IReward
{
    void reward(Player p);
}
