@FunctionalInterface
public interface IRequirement
{
    void take(Player p);
}
