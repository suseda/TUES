@FunctionalInterface
public interface IOptional
{
    boolean test(Player p);
}
