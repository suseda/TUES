public class Cards
{
    String name,text;
    Player player;

    public Cards(String name, String text, Player player) {
        this.name = name;
        this.text = text;
        this.player = player;
    }
}
