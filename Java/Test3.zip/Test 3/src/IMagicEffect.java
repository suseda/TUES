@FunctionalInterface
public interface IMagicEffect
{
    void magic(Player p, MonsterCard m,int power);
}
