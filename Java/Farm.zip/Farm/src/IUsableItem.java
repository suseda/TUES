public interface IUsableItem
{
    void applyItem(Farm farm, Vector2 position, String name, int age_to_grow) throws Exception;
}
