public class FarmCrop extends Seeding
{

    public FarmCrop(String name, Boolean is_grown,int cnt, String type) throws Exception {
        super(name, is_grown,cnt,type);
    }
}
