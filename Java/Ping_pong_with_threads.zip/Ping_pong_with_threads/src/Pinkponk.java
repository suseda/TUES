public class Pinkponk implements Runnable
{
    boolean isBallHere;
    Thread obj;

    public Pinkponk(boolean isBallHere, Thread obj) {
        this.isBallHere = isBallHere;
        this.obj = obj;
    }

    @Override
    public void run()
    {
        while(true)
        {
            if(isBallHere)
            {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                System.out.println("Ball is passed");

                synchronized (obj)
                {
                    obj.notify();
                }
                isBallHere = false;
            }
            else
            {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                try
                {
                    synchronized (obj)
                    {
                        obj.wait();
                    }
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                System.out.println("Ball is received");
                isBallHere = false;
            }
        }
    }
}
