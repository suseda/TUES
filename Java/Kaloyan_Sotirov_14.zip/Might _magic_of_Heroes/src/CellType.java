public abstract  class CellType
{
    public abstract void doSomething(Player activePlayer);
}
