public class Wall extends CellType
{

    @Override
    public void doSomething(Player activePlayer) {

    }
}
