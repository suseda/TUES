import java.util.ArrayList;

public class ComputerController extends PlayerController
{

    public ComputerController(Map gameMap,ArrayList<Player> players) {
        super(gameMap,players);
    }

    @Override
    public void startTurn(Player activePlayer) {

    }

    @Override
    public void run() {

    }

}
