public interface GameEndingCondition
{
    boolean isGameEnded(Game game);
}
