public class Empty extends CellType
{


    @Override
    public void doSomething(Player activePlayer) {

    }
}
