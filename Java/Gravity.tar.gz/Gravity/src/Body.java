public class Body
{
    String name;
    Vector v;
    double m;

    public Body(String name,Vector v,double m)
    {
        this.name = name;
        this.v = v;
        this.m = m;
    }

    public F Calculate_F(Body b)
    {
        double m = this.m * b.m;
        double len = this.v.Sub(b.v);
        Vector new_v = this.v.Vector_Sub(b.v);
        F F = new F(new_v.x,new_v.y,m / (len * len));
        return F;
    }

    public Vector Calculate_acceleration(Vector F)
    {
        Vector a = new Vector(F.x/this.m,F.y/this.m);
        return a;
    }
}
