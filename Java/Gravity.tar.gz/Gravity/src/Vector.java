import java.lang.Math;
public class Vector
{
    double x,y;

    public Vector(double x, double y)
    {
        this.x = x;
        this.y = y;
    }

    public Vector Sum(Vector v)
    {
        Vector new_v = new Vector(this.x+v.x,this.y+v.y);
        return new_v;
    }

    public Vector Vector_Sub(Vector v)
    {
        Vector new_v = new Vector(this.x-v.x,this.y-v.y);
        return new_v;
    }
    public double Sub(Vector v)
    {
        Vector new_v = new Vector(this.x-v.x,this.y-v.y);
        return  new_v.length();
    }

    public double length()
    {
        return Math.abs(Math.sqrt(this.x * this.x + this.y * this.y));
    }

}
