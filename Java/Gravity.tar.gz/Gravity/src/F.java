public class F extends Vector
{
    double power;
    public F(double x, double y,double power)
    {
        super(x, y);
        this.power = power;
    }
}
