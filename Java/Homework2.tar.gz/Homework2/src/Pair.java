public class Pair
{
    Figure f1,f2;

    public Pair(Figure f1, Figure f2)
    {
        this.f1 = f1;
        this.f2 = f2;
    }
}
