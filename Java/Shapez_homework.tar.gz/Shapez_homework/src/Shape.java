public class Shape
{
    char left_up,left_down,right_up,right_down;

    public Shape(char left_up,char left_down,char right_up,char right_down)
    {
        this.left_up = left_up;
        this.left_down = left_down;
        this.right_up = right_up;
        this.right_down = right_down;
    }
}
