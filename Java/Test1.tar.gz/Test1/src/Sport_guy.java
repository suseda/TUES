public abstract class Sport_guy
{
    String name,country;
    int age,points;

    public Sport_guy(String name,String country,int age, int points) {
        this.name = name;
        this.country=country;
        this.age=age;
        this.points=points;
    }

    public String getName() {
        return name;
    }

    public String getCountry() {
        return country;
    }

    public int getAge() {
        return age;
    }

    public int getPoints() {
        return points;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public abstract String toString();
}
