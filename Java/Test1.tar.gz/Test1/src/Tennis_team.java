import java.util.ArrayList;

public class Tennis_team extends Team
{
    Tennis_player player;

    public Tennis_team(String name, String country, String sport,Tennis_player player)
    {
        super(name, country, sport);
        this.player=player;
    }

    String getPreferredCourt()
    {
        if(this.player.hard_wins > this.player.grass_wins && this.player.hard_wins > this.player.clay_wins)
            return "hard";
        else if (this.player.grass_wins  > this.player.clay_wins)
            return "grass";
        else
            return "clay";
    }

    @Override
    public String toString()
    {
        String s = "Name:"+this.name+" Country:"+this.country+" Sport:"+this.sport+this.player.toString();
        return s;
    }

    Tennis_player findStrongestTennisPlayer(ArrayList<Tennis_player> team)
    {
        Tennis_player strongest=team.get(0);
        for(int i = 1;i< team.size();i++)
        {
            double first_player=0,second_player=0;
            first_player = strongest.getClay_wins()+strongest.getHard_wins()+strongest.getGrass_wins();
            second_player = team.get(i).getClay_wins()+team.get(i).getHard_wins()+team.get(i).getGrass_wins();
            first_player = first_player/(strongest.getGames()-first_player);
            second_player = second_player/(team.get(i).getGames()-second_player);
            if(first_player<second_player)
            {
                strongest=team.get(i);
            }
        }
        return strongest;
    }

}
