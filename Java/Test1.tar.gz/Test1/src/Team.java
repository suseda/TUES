public abstract class Team
{
    String name, country,sport;

    public Team(String name,String country,String sport)
    {
        this.name = name;
        this.country=country;
        this.sport=sport;
    }

    public abstract String toString();

}
