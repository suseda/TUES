public class Football_player extends Sport_guy
{
    int games,goals;
    String position,prefered_position;
    public Football_player(String name, String country, int age, int points,int games,int goals,String position,String prefered_position)
    {
        super(name, country, age, points);
        this.games=games;
        this.goals=goals;
        this.position=position;
        this.prefered_position=prefered_position;
    }

    @Override
    public String toString()
    {
        String s = "Games:"+this.games+" Goals:"+this.goals+" Position:"+this.position+" Prefered position:"+this.prefered_position;
        return s;
    }
}
