public class Tennis_player extends Sport_guy
{
    int games;
    int clay_wins,grass_wins,hard_wins;

    public Tennis_player(String name, String country, int age, int points,int games,int clay_wins,int grass_wins,int hard_wins) {
        super(name, country, age, points);
        this.games=games;
        this.clay_wins=clay_wins;
        this.grass_wins=grass_wins;
        this.hard_wins=hard_wins;
    }

    @Override
    public String toString()
    {
        String s =" Games:"+this.games+" Clay wins:"+this.clay_wins+" Grass wins:"+this.grass_wins+" Hard wins:"+this.hard_wins;
        return s;
    }

    public int getGames() {
        return games;
    }

    public void setGames(int games) {
        this.games = games;
    }

    public int getClay_wins() {
        return clay_wins;
    }

    public void setClay_wins(int clay_wins) {
        this.clay_wins = clay_wins;
    }

    public int getGrass_wins() {
        return grass_wins;
    }

    public void setGrass_wins(int grass_wins) {
        this.grass_wins = grass_wins;
    }

    public void setHard_wins(int hard_wins) {
        this.hard_wins = hard_wins;
    }

    public int getHard_wins() {
        return hard_wins;
    }
}
