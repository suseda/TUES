import java.util.ArrayList;

public class Main {
    public static void main(String[] args)
    {
        Tennis_player tennis_player = new Tennis_player("Joe","Canada",24,1000,15,3,3,4);
        System.out.println(tennis_player.toString());

        Tennis_team tennis_team = new Tennis_team("Joe","Canada","Tennis",tennis_player);
        System.out.println(tennis_team.toString());
        System.out.println("Joe preferre cort:");
        System.out.println(tennis_team.getPreferredCourt());
        Tennis_player tennis_player2 = new Tennis_player("Emil","Sweden",24,1000,15,4,4,4);
        ArrayList<Tennis_player> list = new ArrayList<>(5);
        list.add(tennis_player);
        list.add(tennis_player2);
        System.out.println("Strongest");
        Tennis_player strongest = tennis_team.findStrongestTennisPlayer(list);
        System.out.println(strongest);



    }
}