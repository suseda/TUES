import java.util.ArrayList;

public class Football_team extends Team
{
    ArrayList<Football_player> team;


    public Football_team(String name, String country, String sport)
    {
        super(name, country, sport);
    }

    @Override
    public String toString()
    {
        String s = "Name:"+this.name+" Country:"+this.country+" Sport:"+this.sport;
        return s;
    }

    boolean canPlay()
    {
        if(team.size() < 11)
            return false;

        int capitan=0,goalkeeper=0;
        for(int i=0; i< this.team.size();i++)
        {
            if(this.team.get(i).position == "capitan")
                capitan++;
            if(this.team.get(i).position == "goalkeeper")
                goalkeeper++;
        }

        if(goalkeeper == 0 || capitan == 0)
            return false;

        int player_cnt=0;
        for(int j = 0; j< this.team.size();j++)
        {
            if(this.team.get(j).position == "capitan" && this.team.get(j).position == "goalkeeper")
                player_cnt++;
        }

        if(player_cnt < 9)
            return false;

        return true;
    }

}
