public interface Entity
{
    int getId();
}
