public class Vegetables extends Product
{

    public Vegetables(String name) {
        super(name);
    }
}
