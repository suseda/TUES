public class Bread extends Product
{

    public Bread(String name) {
        super(name);
    }
}
