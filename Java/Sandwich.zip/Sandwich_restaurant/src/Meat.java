public class Meat extends Product
{

    public Meat(String name) {
        super(name);
    }
}
