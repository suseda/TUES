public class Sauce extends Product
{

    public Sauce(String name) {
        super(name);
    }
}
