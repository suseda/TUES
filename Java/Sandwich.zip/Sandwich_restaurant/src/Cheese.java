public class Cheese extends Product
{
    public Cheese(String name)
    {
        super(name);
    }
}
